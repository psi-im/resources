srvLoader.setMetaData({
    name: "Bubble-gum",
    version: "1.1",
    authors: ["Sergei Ilinykh <rion4ik@gmail.com>", "Eugene_K", "satrap"],
    description: "Bubble-gum style.",
    url: "https://psi-im.org",
    features: ["reactions", "message-retract", "bubble-gum"],
    stylesList: ["Light", "Dark"]
});
